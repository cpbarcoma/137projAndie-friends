public enum Direction { 	//file setting parameters Up Down Left Right and STOP action
	L, U, R, D, STOP
}
